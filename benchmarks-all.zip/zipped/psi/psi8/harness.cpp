#include "psi8.hpp"

#include <iostream>
#include <iterator>
#include <openfhe.h>
#include <chrono>
#include <random>

using namespace lbcrypto;
using BinFHEContextT = std::shared_ptr<BinFHEContext>;
using LWEInt = std::vector<LWECiphertext>;

int main(int argc, char **argv) {
    auto cc = std::make_shared<BinFHEContext>(BinFHEContext());
    cc->GenerateBinFHEContext(BINFHE_PARAMSET::TOY, true, 12);
    auto sk = cc->KeyGen();
    cc->BTKeyGen(sk);

    std::mt19937 rand;

    std::vector<int> set1, set2;
    set1.reserve(8);
    set2.reserve(8);
    for (int i = 0; i < 8; i++) {
        set1.push_back(rand() & 0xff);
        set2.push_back(rand() & 0xff);
    }

    std::vector<LWEInt> encryptedSet1;
    std::vector<LWEInt> encryptedSet2;

    std::transform(set1.begin(), set1.end(), std::back_inserter(encryptedSet1), [cc, sk](auto ptxt) { return encrypt(cc, sk, ptxt, 8); });
    std::transform(set2.begin(), set2.end(), std::back_inserter(encryptedSet2), [cc, sk](auto ptxt) { return encrypt(cc, sk, ptxt, 8); });
    
    std::vector<size_t> times;
    times.reserve(30);
    
    for (int i = 0; i < 30; i++) {
        std::cerr << i + 1 << "/30...";
        auto start = std::chrono::high_resolution_clock::now();
        auto intersection = psi8(cc, encryptedSet1, encryptedSet2);
        auto end = std::chrono::high_resolution_clock::now();
        times.push_back(std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count());
        std::cerr << times[times.size() - 1] << "\n";
    }

    for (auto time : times) std::cout << time << ",";
    std::cout << "\n";
    
    return 0;
}