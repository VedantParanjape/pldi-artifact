#include "mul16.hpp"

#include "lwe-ciphertext-fwd.h"
#include <iostream>
#include <memory>
#include <openfhe.h>
#include <chrono>
#include <random>

using namespace lbcrypto;
using BinFHEContextT = std::shared_ptr<BinFHEContext>;
using LWEInt = std::vector<LWECiphertext>;

int main(int argc, char **argv) {
    auto cc = std::make_shared<BinFHEContext>(BinFHEContext());
    cc->GenerateBinFHEContext(BINFHE_PARAMSET::TOY, true, 12);
    auto sk = cc->KeyGen();
    cc->BTKeyGen(sk);

    std::vector<LWEInt> xs, ys;
    xs.reserve(30);
    ys.reserve(30);

    std::mt19937 rand(123);
    for (int i = 0; i < 30; i++) {
        xs.push_back(encrypt(cc, sk, rand() % 65536, 16));
        ys.push_back(encrypt(cc, sk, rand() % 65536, 16));
    }


    std::vector<size_t> times;
    times.reserve(30);

    for (int i = 0; i < 30; i++) {
        auto& x = xs[i];
        auto& y = ys[i];
        std::cerr << i + 1 << "/30..."; 
        auto start = std::chrono::high_resolution_clock::now();
        auto out = mul16(cc, x, y);
        auto end = std::chrono::high_resolution_clock::now();
        times.push_back(std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count());
        std::cerr << times[times.size() - 1] << "\n";
    }

    for (auto time : times) {
        std::cout << time << ",";
    }
    std::cout << "\n";

    return 0;
}
