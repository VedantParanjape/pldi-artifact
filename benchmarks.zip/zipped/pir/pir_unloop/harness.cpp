#include "pir_unloop.hpp"

#include <iostream>
#include <memory>
#include <openfhe.h>
#include <chrono>
#include <random>


using namespace lbcrypto;
using BinFHEContextT = std::shared_ptr<BinFHEContext>;
using LWEInt = std::vector<LWECiphertext>;

int main(int argc, char **argv) {
    auto cc = std::make_shared<BinFHEContext>(BinFHEContext());
    cc->GenerateBinFHEContext(BINFHE_PARAMSET::TOY, true, 12);
    auto sk = cc->KeyGen();
    cc->BTKeyGen(sk);

    std::vector<LWEInt> keys, values;
    keys.reserve(8);
    values.reserve(8);

    for (int i = 0; i < 8; i++) {
        keys.push_back(encrypt(cc, sk, rand() & 0xff, 8));
        values.push_back(encrypt(cc, sk, rand() & 0xff, 8));
    }

    auto key = encrypt(cc, sk, rand() & 0xff, 8);

    std::vector<size_t> times;
    times.reserve(30);

    for (int i = 0; i < 30; i++) {
        std::cerr << i+1 << "/30...";
        auto start = std::chrono::high_resolution_clock::now();
        auto out = pir_unloop(cc, keys, values, key);
        auto end = std::chrono::high_resolution_clock::now();    
        times.push_back(std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count());
        std::cerr << times[times.size() - 1] << "\n";
    }
    // auto start = std::chrono::high_resolution_clock::now();
    // auto out = pir_loop(cc, in);
    // auto end = std::chrono::high_resolution_clock::now();
    // int outPtxt = decrypt(cc, sk, out);
    // std::cout << "Result: " << outPtxt << "\n";
    // std::cout << "pir_loop took " 
    //           << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << "ms\n";
    
    for (auto time : times) {
        std::cout << time << ",";
    }
    std::cout << "\n";

    return 0;
}