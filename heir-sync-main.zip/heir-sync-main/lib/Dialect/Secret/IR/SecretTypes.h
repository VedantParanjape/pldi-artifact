#ifndef LIB_DIALECT_SECRET_IR_SECRETTYPES_H_
#define LIB_DIALECT_SECRET_IR_SECRETTYPES_H_

#include "lib/Dialect/Secret/IR/SecretDialect.h"

#define GET_TYPEDEF_CLASSES
#include "lib/Dialect/Secret/IR/SecretTypes.h.inc"

#endif  // LIB_DIALECT_SECRET_IR_SECRETTYPES_H_
