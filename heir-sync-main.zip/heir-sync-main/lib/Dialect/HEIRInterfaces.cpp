// Block clang-format from thinking the header is unused
// IWYU pragma: begin_keep
#include "lib/Dialect/HEIRInterfaces.h"
// IWYU pragma: end_keep

namespace mlir {
namespace heir {
#include "lib/Dialect/HEIRInterfaces.cpp.inc"
}
}  // namespace mlir
