#ifndef LIB_DIALECT_TFHERUSTBOOL_IR_TFHERUSTBOOLTYPES_H_
#define LIB_DIALECT_TFHERUSTBOOL_IR_TFHERUSTBOOLTYPES_H_

#include "lib/Dialect/TfheRustBool/IR/TfheRustBoolDialect.h"

#define GET_TYPEDEF_CLASSES
#include "lib/Dialect/TfheRustBool/IR/TfheRustBoolTypes.h.inc"

#endif  // LIB_DIALECT_TFHERUSTBOOL_IR_TFHERUSTBOOLTYPES_H_
