#ifndef LIB_DIALECT_JAXITE_IR_JAXITETYPES_H_
#define LIB_DIALECT_JAXITE_IR_JAXITETYPES_H_

#include "lib/Dialect/Jaxite/IR/JaxiteDialect.h"

#define GET_TYPEDEF_CLASSES
#include "lib/Dialect/Jaxite/IR/JaxiteTypes.h.inc"

#endif  // LIB_DIALECT_JAXITE_IR_JAXITETYPES_H_
