---
title: HEIR meeting 2023-07-18
date: 2023-07-18T10:43:16-0700
linkTitle: HEIR meeting 2023-07-18
description: >
  Notes from the 2023-07-18 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

The third HEIR meeting was 2023-07-18
([notes](https://docs.google.com/document/d/1DXdyUCmevqY8RJI3kM8oO5nWDEITFIVBPIbucONOB-k/edit?usp=sharing)).

We decided to schedule future meetings every two weeks, with alternating focus
on MLIR and Hardware. See the [meeting calendar](https://heir.dev/community/) to
join.
([direct link to the calendar](https://calendar.google.com/calendar/u/0/embed?src=c85ecb3cda4bfb7daa3da95d5aeb19672930501b49d17896e65fa3f963f17a80@group.calendar.google.com&ctz=America/Los_Angeles))
