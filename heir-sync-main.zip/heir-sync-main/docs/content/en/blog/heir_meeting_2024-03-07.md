---
title: HEIR meeting 2024-03-07
date: 2024-03-07T00:00:00+00:00
linkTitle: HEIR meeting 2024-03-07
description: >
  Notes from the 2024-03-07 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1felxN5mFBV5LheP79is30jHRxlKLW0NQEo6FPDKxDKM/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1oVJG-fM72nNLiR1eXkzdeaqdDOEpTfK0/view?usp=sharing)
from the HEIR meeting on 2024-03-07.

Note: there will be no HEIR meeting on 2024-03-21 due to the FHE.org, HACS, and
RWC conferences. Hope to see you all there!
