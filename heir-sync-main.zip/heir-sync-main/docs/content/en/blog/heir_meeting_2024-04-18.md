---
title: HEIR meeting 2024-04-18
date: 2024-04-18T00:00:00+00:00
linkTitle: HEIR meeting 2024-04-18
description: >
  Notes from the 2024-04-18 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1BJjfYI2yjR3YEg_ugjDuS-trAkYMlKbU7jpH_M1GF3Q/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1WSsUp9CmjDmEVtGMYk2QXIpZCEetf_Ot/view?usp=sharing)
from the HEIR meeting on 2024-04-18.
