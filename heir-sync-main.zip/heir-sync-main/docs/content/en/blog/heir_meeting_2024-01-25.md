---
title: HEIR meeting 2024-01-25
date: 2024-01-25T00:00:00+00:00
linkTitle: HEIR meeting 2024-01-25
description: >
  Notes from the 2024-01-25 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1yrkAVR_348vT3SD7apb9QDoFIgz0bjHn-SzT2GOacfs/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/11JTfRy_3LvHjJQe0nJuqe8WGa8F9oHu1/view?usp=sharing)
from the HEIR meeting on 2024-01-25.
