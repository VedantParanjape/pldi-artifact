---
title: HEIR meeting 2024-07-25
date: 2024-07-25T00:00:00+00:00
linkTitle: HEIR meeting 2024-07-25
description: >
  Notes from the 2024-07-25 HEIR meeting.
author: '[Asra Ali](https://github.com/asraa)'
---

Here are the
[notes](https://docs.google.com/document/d/1tIrxc4V5OlAeqx_Z1rl_kuMmkd-HUAKEv90q3i-5QSU/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1_1CbRJeNr5NqcwEMXnfkxOqy9u5wJPyq/view?usp=sharing)
from the HEIR meeting on 2024-07-25.
