---
title: HEIR meeting 2024-08-08
date: 2024-08-08T00:00:00+00:00
linkTitle: HEIR meeting 2024-08-08
description: >
  Notes from the 2024-08-08 HEIR meeting.
author: '[Asra Ali](https://github.com/asraa)'
---

Here are the
[notes](https://docs.google.com/document/d/1FLSiaPlX38GNHqqqi_Mz3gMuVSlS4sUcwBWqpt6Fkew/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1sHoRvNlS14RB-r3Rk0y2RyWOERVGNc-t/view?usp=sharing)
from the HEIR meeting on 2024-08-08.
