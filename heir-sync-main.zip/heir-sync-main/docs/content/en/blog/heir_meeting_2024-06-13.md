---
title: HEIR meeting 2024-06-13
date: 2024-06-13T00:00:00+00:00
linkTitle: HEIR meeting 2024-06-13
description: >
  Notes from the 2024-06-13 HEIR meeting.
author: '[Asra Ali](https://github.com/asraa)'
---

Here are the
[notes](https://docs.google.com/document/d/1rkPxOdbJY5J6qhsciZ0rfdj5_9PG_Ng-6USBUvLrEeU/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/19oQOYlvfeHoSwWqOC4hXZTBuaPIf1zQl/view?usp=sharing)
from the HEIR meeting on 2024-06-13.
