---
title: HEIR meeting 2023-08-15
date: 2023-08-16T16:15:47+00:00
linkTitle: HEIR meeting 2023-08-15
description: >
  Notes from the 2023-08-15 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1vZsKJH4wCAZCtyh3o9nNMLRFwlWQiVdvUMvwJnA4cIc/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1DDNepYCSqgi-JlBLBzHrsL5CjjiwqcA_/view?usp=sharing)
from the HEIR meeting on 2023-08-15.
