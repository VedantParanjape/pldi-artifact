---
title: HEIR meeting 2023-08-01
date: 2023-08-02T15:46:42-0700
linkTitle: HEIR meeting 2023-08-01
description: >
  Notes from the 2023-08-01 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

The fourth HEIR meeting was 2023-08-01
([notes](https://docs.google.com/document/d/1gid-MARMUStb3dB9jsXEV_CnPDpf_9cyPXy9uXtZk08/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1U6HDdKJo3-UHibFPgNrDakU8EpCt5xHZ/view?usp=sharing)).

We're also starting on the Poly and Secret dialects in
[#74 (poly)](https://github.com/google/heir/pull/74) and
[#78 (secret)](https://github.com/google/heir/pull/78), so please join in the
fun!
