---
title: HEIR meeting 2024-02-22
date: 2024-02-22T00:00:00+00:00
linkTitle: HEIR meeting 2024-02-22
description: >
  Notes from the 2024-02-22 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1ktK2Y2-OnadvsIIa94HRch_oHCaQ0D6gbT3CElKmGak/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1RDONadr54-7uX5ko5dmUX3s1l7QHeHbM/view?usp=sharing)
from the HEIR meeting on 2024-02-22.
