---
title: HEIR meeting 2024-04-04
date: 2024-04-04T00:00:00+00:00
linkTitle: HEIR meeting 2024-04-04
description: >
  Notes from the 2024-04-04 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/121_0mzqYIWYMc7rcW2Et5qS-ux4ut3b-kno1dI9sQq8/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1_Ksjx8s8nD4cLsuZp5_KitYI2mPN72Je/view?usp=sharing)
from the HEIR meeting on 2024-04-04.
