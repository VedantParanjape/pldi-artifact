---
title: HEIR meeting 2024-05-02
date: 2024-05-02T00:00:00+00:00
linkTitle: HEIR meeting 2024-05-02
description: >
  Notes from the 2024-05-02 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1uEDeIN0iTUmmtlacZg0c2j7VbAHO3A9e0_8mnunUv10/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1u1q74rUKdXFi08tAKFRKjI-bojuorQK8/view?usp=drivesdk)
from the HEIR meeting on 2024-05-02.
