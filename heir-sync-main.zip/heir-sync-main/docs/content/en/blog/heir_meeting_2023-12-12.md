---
title: HEIR meeting 2023-12-12
date: 2023-12-12T00:00:00+00:00
linkTitle: HEIR meeting 2023-12-12
description: >
  Notes from the 2023-12-12 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1ekGrOBLoB_F3qjC43r6NzJbWpgT9RILTJyVu5Ax3PCQ/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1DaYj9euovyf8vuCi260RQYfEkItn4SEc/view?usp=sharing)
from the HEIR meeting on 2023-12-12.

This is the last meeting for 2023. Please respond to
[this poll](https://app.rallly.co/invite/fHNdzrbisHVA) for 2024 scheduling
preferences.
