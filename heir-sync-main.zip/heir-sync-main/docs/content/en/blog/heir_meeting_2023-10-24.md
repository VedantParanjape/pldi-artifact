---
title: HEIR meeting 2023-10-24
date: 2023-10-25T00:00:00+00:00
linkTitle: HEIR meeting 2023-10-24
description: >
  Notes from the 2023-10-24 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1MYjjkytck0fxySbrh49hxBJgNM78NXSD0ZwzAgEPOUw/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1zrSCQJXta40KbBiCjcIWOP3gd1tuc3MU/view?usp=sharing)
from the HEIR meeting on 2023-10-24.

Also of note: our talk at FHE.org was last Thursday
([recording](https://www.youtube.com/watch?v=kqDFdKUTNA4)), and the similar talk
at the LLVM developers meeting talk was the previous Wednesday, though the video
has not yet been posted for that.
