---
title: HEIR meeting 2024-08-22
date: 2024-08-22T00:00:00+00:00
linkTitle: HEIR meeting 2024-08-22
description: >
  Notes from the 2024-08-22 HEIR meeting.
author: '[Asra Ali](https://github.com/asraa)'
---

Here are the
[notes](https://docs.google.com/document/d/1iEkzpO6lCVbShMcRenO3j3DptOEP-0bLu_9V4K7c39M/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1wFrGF7lMiYZmqbr5WQO17HomfoFoOeaj/view?usp=sharing)
from the HEIR meeting on 2024-08-22.
