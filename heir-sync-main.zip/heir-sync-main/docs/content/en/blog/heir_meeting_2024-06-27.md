---
title: HEIR meeting 2024-06-27
date: 2024-06-27T00:00:00+00:00
linkTitle: HEIR meeting 2024-06-27
description: >
  Notes from the 2024-06-27 HEIR meeting.
author: '[Asra Ali](https://github.com/asraa)'
---

Here are the
[notes](https://docs.google.com/document/d/1lc4U2JzHapu99_sigOAYwpjNnfd9_QGrX1HAQ0hle_o/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1-wMytGj3AHi55sA2jb81AsHOU8EcIq6d/view?usp=sharing)
from the HEIR meeting on 2024-06-27.
