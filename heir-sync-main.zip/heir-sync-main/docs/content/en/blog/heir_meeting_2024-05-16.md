---
title: HEIR meeting 2024-05-16
date: 2024-05-16T00:00:00+00:00
linkTitle: HEIR meeting 2024-05-16
description: >
  Notes from the 2024-05-16 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/15MwanXaBap6qNzYj7g1m6zRcqK363O-3iCCcNcGY1Ds/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1gOf_Tb8k9UNx7i0OvjjikkYUG3HrPjoS/view?usp=sharing)
from the HEIR meeting on 2024-05-16.
