---
title: Hello, World!
date: 2023-06-13T13:15:10-07:00
linkTitle: Hello, World!
description: >
  We're starting a compiler toolchain for homomorphic encryption compilers.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Hello, world! We're starting a project to unify homomorphic encryption compiler
IRs.

Our initial meeting was 2023-05-30
([read-only copy of the minutes](https://docs.google.com/document/d/1iyiHfseoVkA1qaP3Ig47kqVC-J1_AIidPaj61jvj2KM/edit?usp=sharing)).
Stay tuned for future updates while we work out a meeting schedule.
