---
title: HEIR meeting 2023-11-28
date: 2023-11-28T00:00:00+00:00
linkTitle: HEIR meeting 2023-11-28
description: >
  Notes from the 2023-11-28 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1-kkkG__qlAtsp50YXxHC7Dq__Qvgb4BcLZCopzJOzE4/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1ykxaqlfVExqGC6saiSnfM2A7_TpWqKiE/view)
from the HEIR meeting on 2023-11-28.
