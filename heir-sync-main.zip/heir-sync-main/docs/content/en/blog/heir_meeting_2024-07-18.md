---
title: HEIR meeting 2024-07-18 (mod_arith dialect)
date: 2024-07-18T00:00:00+00:00
linkTitle: HEIR meeting 2024-07-18 (mod_arith dialect)
description: >
  Notes from the 2024-07-18 HEIR meeting.
author: '[Asra Ali](https://github.com/asraa)'
---

Here are the
[notes](https://docs.google.com/document/d/1o2-I03DJtNJQDupSHn8LtOXLmxsd3WO1fjvqLbT-SIc/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1bCMuuKnBVf6HP7R2SiZgo1C1vsG6FzF2/view?usp=sharing)
from the HEIR meeting on 2024-07-18. This special discussion was focused on the
modular arithmetic dialect.
