---
title: HEIR meeting 2024-05-30
date: 2024-05-30T00:00:00+00:00
linkTitle: HEIR meeting 2024-05-30
description: >
  Notes from the 2024-05-30 HEIR meeting.
author: Asra Ali
---

Here are the
[notes](https://docs.google.com/document/d/1mvigwMRTeVQvdpm2hwiewfU8jcJT94ArQBNvngvgkTc/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1CTIyd7HRiNV857VO2EonquWZZlBhysLM/view?usp=sharing)
from the HEIR meeting on 2024-05-30.
