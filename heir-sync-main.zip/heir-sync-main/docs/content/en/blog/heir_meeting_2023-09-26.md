---
title: HEIR meeting 2023-09-26
date: 2023-09-27T00:00:00+00:00
linkTitle: HEIR meeting 2023-09-26
description: >
  Notes from the 2023-09-26 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1pkG8eaSUddAySJWjQHIFqe0hyYkO0wH9X0JtnR6wlWo/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1xaH-G3SZPVv_gEpUkfhFuvUTUwU2ZKLY/view?usp=sharing)
from the HEIR meeting on 2023-09-26.

Next meeting (Oct 10) is canceled for the MLIR workshop, and I'll post an update
from that workshop on this blog, hopefully also with a video of the talk that
Alex Viand and I will be giving at the LLVM developers meeting.
