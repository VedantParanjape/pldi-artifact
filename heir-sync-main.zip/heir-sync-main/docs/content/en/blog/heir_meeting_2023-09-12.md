---
title: HEIR meeting 2023-09-12
date: 2023-09-13T00:00:00+00:00
linkTitle: HEIR meeting 2023-09-12
description: >
  Notes from the 2023-09-12 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1gOH1V6ORQwJDDo6I4jrDgCqqNFTsfcQbfpdUR6tv_60/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1zFtpBcCCq5d6UD8Nm8r3rfg3sgy-guz7/view?usp=sharing)
from the HEIR meeting on 2023-09-12.
