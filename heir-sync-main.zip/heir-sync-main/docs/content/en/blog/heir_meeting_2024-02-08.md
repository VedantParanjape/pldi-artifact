---
title: HEIR meeting 2024-02-08
date: 2024-02-08T00:00:00+00:00
linkTitle: HEIR meeting 2024-02-08
description: >
  Notes from the 2024-02-08 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1w0Cc3YfbSNO4PYVdGjb8KpE5rql8zgoDG2X0Yseon_4/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1rTsc-sWdRCqJWONrgGo5FV7CQd1S_OV-/view?usp=sharing)
from the HEIR meeting on 2024-02-08.
