---
title: HEIR meeting 2023-08-29
date: 2023-09-05T00:00:00+00:00
linkTitle: HEIR meeting 2023-08-29
description: >
  Notes from the 2023-08-29 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1Lax8Inby5Mg8BZLkcV_5hUiWH-roL22rtszfc0PBGmE/edit?usp=sharing)
from the HEIR meeting on 2023-08-29. There was an issue with the recording, so
there is no video recording this week.
