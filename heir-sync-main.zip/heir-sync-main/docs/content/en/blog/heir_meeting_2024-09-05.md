---
title: HEIR meeting 2024-09-05
date: 2024-09-05T00:00:00+00:00
linkTitle: HEIR meeting 2024-09-05
description: >
  Notes from the 2024-09-05 HEIR meeting.
author: '[Asra Ali](https://github.com/asraa)'
---

Here are the
[notes](https://docs.google.com/document/d/1tohVmC2pn_XDn3gjCFeo3K4Wfyf7VWu3oK1vimEsFD4/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1XGheLF7kvJfwAMJJQ-XbDpa4Ld15kj4t/view?usp=sharing)
from the HEIR meeting on 2024-09-05.
