---
title: HEIR meeting 2023-11-07
date: 2023-11-07T00:00:00+00:00
linkTitle: HEIR meeting 2023-11-07
description: >
  Notes from the 2023-11-07 HEIR meeting.
author: '[Jeremy Kun](https://jeremykun.com)'
---

Here are the
[notes](https://docs.google.com/document/d/1nOlAhul4DwZU8UQPpTF1i3OldSY9EmwaWG3EPSZIhHs/edit?usp=sharing)
and
[video recording](https://drive.google.com/file/d/1I7aIipm54CCcDcLyRYXI_gARfT1z93cN/view?usp=sharing)
from the HEIR meeting on 2023-11-07.
