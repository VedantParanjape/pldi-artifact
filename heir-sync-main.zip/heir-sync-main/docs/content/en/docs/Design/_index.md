---
title: Design
weight: 50
---

This section contains documentation on the high level design of the project.
Readers are intended to have basic familiarity with MLIR and FHE.
