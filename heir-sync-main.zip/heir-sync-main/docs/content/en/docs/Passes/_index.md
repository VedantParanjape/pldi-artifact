---
title: Passes
weight: 90
---

This section contains the passes defined by HEIR.
