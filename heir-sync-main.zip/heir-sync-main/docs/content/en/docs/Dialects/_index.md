---
title: Dialects
weight: 70
---

This section contains the reference documentation for all of the dialects
defined in HEIR.
